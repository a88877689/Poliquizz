from .auth import AuthResource
from .user import UserResource
from .exam import ExamResource
from .quizz import QuizzResource
from .xml import XMLResource