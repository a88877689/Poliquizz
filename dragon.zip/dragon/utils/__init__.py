from .auth import token_required
from .compere import compere
from .password import encode
from .password import check
from .xml import xml_resource